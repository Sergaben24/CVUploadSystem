<?php
session_start();
session_destroy();
?>
<p>Logged out.</p>
<p><a href="login1.php">login1.php</a></p>
<p><a href="login2.php">login2.php</a></p>
